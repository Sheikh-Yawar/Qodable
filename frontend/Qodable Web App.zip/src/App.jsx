import React, { useState } from "react";
import Editor from "@monaco-editor/react";
import SpeechRecognition, {
  useSpeechRecognition,
} from "react-speech-recognition";
import "./App.css";

function App() {
  const [code, setCode] = useState();
  const [isListening, setIsListening] = useState(false);
  const { transcript, resetTranscript } = useSpeechRecognition();

  const handleMicClick = () => {
    if (!isListening) {
      resetTranscript();
      SpeechRecognition.startListening({ continuous: true });
      setIsListening(true);
    } else {
      SpeechRecognition.stopListening();
      const instruction = transcript.trim();
      const apiUrl = `http://127.0.0.1:5000/qd/python?instruct=${instruction}`;

      // Send API request
      fetch(apiUrl, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      })
        .then((response) => response.json())
        .then((data) => {
          console.log(data);
          handleNewCode(data.statements[0]);
        })
        .catch((error) => {
          console.error("Error:", error);
        });

      setIsListening(false);
    }
  };

  const handleNewCode = (newCode) => {
    setCode(newCode);
  };

  return (
    <div>
      <div className="header">
        <p>Qodable</p>
      </div>

      <Editor
        height="100vh"
        width="100vw"
        language="javascript"
        theme="vs-dark"
        value={code}
        onChange={handleNewCode}
        options={{
          fontSize: 20,
          fontFamily: "Fira Code",
          padding: {
            top: 10,
          },
          bracketPairColorization: true,
          smoothScrolling: true,
        }}
      />
      {!isListening && (
        <div
          onClick={handleMicClick}
          title="Start Asking"
          className="microphone"
        >
          <img src="../assets/mic.png" />
        </div>
      )}
      {isListening && (
        <div
          onClick={handleMicClick}
          title="Stop Asking"
          className="microphone"
          style={{
            backgroundColor: "transparent",
          }}
        >
          <img src="../assets/stop.png" />
        </div>
      )}

      {isListening && <div className="footer">{transcript}</div>}
    </div>
  );
}

export default App;
